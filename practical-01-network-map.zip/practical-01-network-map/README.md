# Practical 01 — Network Map

> **Course:** Networking, Cloud & GitHub Pipelines  
> **Module:** 1 — Networking Fundamentals  
> **Competency:** Demonstrate understanding of OSI layers, IP addressing, DNS, TCP/UDP, ports, and HTTP/S using real terminal tools.

---

## What this practical covers

| Tool | Concept proved |
|------|----------------|
| `ifconfig` / `ip addr` | IP addressing, subnets, CIDR |
| `traceroute` | Routing, TTL, network hops |
| `nslookup` / `dig` | DNS record types, resolution |
| `netstat` / `ss` | Ports, TCP connections, Layer 4 |
| `curl -v` | Full HTTP/S stack, TLS handshake |

---

## Repository structure

```
practical-01-network-map/
├── README.md                  ← this file (summary + answers)
├── screenshots/               ← terminal output screenshots
└── exercises/
    ├── 1-ifconfig.md          ← Exercise 1: local network mapping
    ├── 2-traceroute.md        ← Exercise 2: packet route tracing
    ├── 3-dns.md               ← Exercise 3: DNS resolution
    ├── 4-ports.md             ← Exercise 4: open ports inspection
    └── 5-curl.md              ← Exercise 5: HTTP/S request capture
```

---

## Competency checklist

- [ ] Can identify a machine's IP, subnet, and gateway from `ifconfig` output
- [ ] Can convert a subnet mask to CIDR notation and calculate host count
- [ ] Can interpret every hop in a `traceroute` output
- [ ] Can query and explain A, MX, CNAME, and TXT DNS records
- [ ] Can identify listening ports and the services behind them
- [ ] Can read a TLS handshake in `curl -v` output and explain each step
- [ ] Can explain the difference between TCP and UDP with real port examples

---

## How to run these exercises

All exercises use tools built into macOS/Linux. On Windows use WSL2 or Git Bash.

```bash
# Verify tools are available
which ping traceroute nslookup dig netstat curl
# or on Linux:
which ping traceroute nslookup dig ss curl
```

No installs required — these are standard UNIX networking tools.

---

## Summary of findings

> **Complete this section after finishing all 5 exercises.**

| Field | Value |
|-------|-------|
| My private IP | _fill in_ |
| My subnet (CIDR) | _fill in_ |
| My default gateway | _fill in_ |
| Usable hosts in subnet | _fill in_ |
| Hops to google.com | _fill in_ |
| google.com resolved IP | _fill in_ |
| TLS version negotiated | _fill in_ |
| TLS cipher suite | _fill in_ |

---

*Part of the [Networking, Cloud & GitHub Pipelines](../README.md) course.*
