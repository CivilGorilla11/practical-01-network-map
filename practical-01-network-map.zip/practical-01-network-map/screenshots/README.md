# Screenshots

Add your terminal screenshots here as you complete each exercise.

| File | Exercise |
|------|---------|
| `1-ifconfig.png` | Exercise 1 — ifconfig / ip addr output |
| `2-traceroute.png` | Exercise 2 — traceroute to google.com |
| `3-dns-trace.png` | Exercise 3 — dig +trace output |
| `4-ports.png` | Exercise 4 — netstat listening ports + python server |
| `5-curl.png` | Exercise 5 — curl -v HTTPS output |

## How to take terminal screenshots

**macOS:** `Cmd + Shift + 4` → drag to select terminal area  
**Linux:** `gnome-screenshot`, `scrot`, or `Shift + PrtSc`  
**Windows:** `Win + Shift + S`

## Tip: save terminal output as text too

```bash
# Pipe output to a file for easy reference
traceroute google.com | tee screenshots/2-traceroute.txt
dig +trace google.com | tee screenshots/3-dns-trace.txt
curl -v https://httpbin.org/get 2>&1 | tee screenshots/5-curl.txt
```

The `2>&1` redirects stderr (where curl -v writes) to stdout so it gets captured.
