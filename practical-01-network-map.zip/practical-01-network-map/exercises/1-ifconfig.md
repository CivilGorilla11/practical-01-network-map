# Exercise 1 — Map your local network

**Concept:** IP addressing, subnet masks, CIDR notation, OSI Layer 3

---

## Commands to run

```bash
# macOS / Linux
ifconfig
ip addr show
ip route show

# Windows
ipconfig /all
```

---

## What to look for in the output

```
# Example ifconfig output — yours will differ
en0: flags=8863<UP,BROADCAST,SMART,RUNNING,SIMPLEX,MULTICAST> mtu 1500
    inet 192.168.1.105 netmask 0xffffff00 broadcast 192.168.1.255
```

| Field | What it means |
|-------|---------------|
| `inet` | Your machine's IPv4 address on this network |
| `netmask` | Defines which part is network vs host (hex here — convert to dotted decimal) |
| `broadcast` | Packets sent here go to ALL devices on your subnet |
| `mtu` | Maximum Transmission Unit — largest frame size this interface accepts |

---

## Converting netmask hex → dotted decimal → CIDR

```
0xffffff00
= 255.255.255.0
= /24  (24 network bits set to 1)
```

Quick reference:

| Hex | Dotted decimal | CIDR | Usable hosts |
|-----|----------------|------|-------------|
| 0xffffff00 | 255.255.255.0 | /24 | 254 |
| 0xfffffe00 | 255.255.254.0 | /23 | 510 |
| 0xffff0000 | 255.255.0.0 | /16 | 65,534 |
| 0xffffff80 | 255.255.255.128 | /25 | 126 |
| 0xfffffffc | 255.255.255.252 | /30 | 2 |

---

## Finding your default gateway

```bash
ip route show
# Look for: default via 192.168.1.1 dev en0

# macOS
netstat -nr | grep default

# Windows
ipconfig /all
# Look for: Default Gateway
```

The gateway is your router — it's the first hop for any traffic leaving your local network.

---

## Calculating your subnet range

Given IP `192.168.1.105` and mask `/24`:

```
Network address:   192.168.1.0    (host bits all 0)
First usable host: 192.168.1.1
Last usable host:  192.168.1.254
Broadcast:         192.168.1.255  (host bits all 1)
Usable hosts:      254  (2^8 - 2)
```

---

## Your answers

> Fill these in after running the commands.

```
My interface name:        _______________________
My IP address:            _______________________
My netmask (hex):         _______________________
My netmask (dotted):      _______________________
My CIDR notation:         _______________________
My broadcast address:     _______________________
My default gateway:       _______________________
Usable hosts in subnet:   _______________________
```

---

## Screenshot

> Add a screenshot of your `ifconfig` / `ip addr show` output here.
> 
> In Markdown:
> ```
> ![ifconfig output](../screenshots/1-ifconfig.png)
> ```

---

## Reflection questions

1. Why does your machine have a private IP (192.168.x.x or 10.x.x.x) and not a public IP?
2. What would happen if two devices on your network had the same IP address?
3. Your machine probably also has a `lo` (loopback) interface at `127.0.0.1`. What is it used for?

> Write your answers here.

---

*Next: [Exercise 2 — Traceroute](./2-traceroute.md)*
