# Exercise 4 — Inspect open ports and connections

**Concept:** TCP/UDP ports, Layer 4 Transport, listening vs established connections

---

## Commands to run

```bash
# All listening ports
netstat -an | grep LISTEN

# Active (established) connections
netstat -an | grep ESTABLISHED

# Linux — ss is the modern replacement for netstat
ss -tulpn                         # TCP+UDP listening, with process names
ss -tnp                           # TCP established, with process names

# macOS — see process owning a port
lsof -i :443                      # what's using port 443?
lsof -i TCP -s TCP:LISTEN         # all TCP listeners with process names

# Start a test server to inspect
python3 -m http.server 8080       # run this in a separate terminal
# then in another terminal:
netstat -an | grep 8080
lsof -i :8080
```

---

## Understanding the output

```bash
$ netstat -an | grep LISTEN

tcp4    0    0  0.0.0.0.22       0.0.0.0.*    LISTEN    ← SSH listening on all interfaces
tcp4    0    0  127.0.0.1.5432   0.0.0.0.*    LISTEN    ← PostgreSQL, localhost only
tcp6    0    0  *.443            *.*          LISTEN    ← HTTPS
tcp4    0    0  0.0.0.0.8080     0.0.0.0.*    LISTEN    ← your test server
```

| Column | Meaning |
|--------|---------|
| `tcp4` / `tcp6` | Protocol and IP version |
| `Local Address` | IP:port your machine is listening on |
| `Foreign Address` | Remote end (0.0.0.0.* = any) |
| `State` | LISTEN / ESTABLISHED / TIME_WAIT / CLOSE_WAIT |

### Listen address meanings

| Address | Meaning |
|---------|---------|
| `0.0.0.0:8080` | Accept connections from ANY IP (external accessible) |
| `127.0.0.1:5432` | Only accept from localhost (not accessible from outside) |
| `::1:6379` | IPv6 localhost only |
| `192.168.1.x:8080` | Only on that specific interface |

---

## Well-known ports to recognise

| Port | Protocol | Service |
|------|----------|---------|
| 22 | TCP | SSH |
| 25 | TCP | SMTP (email sending) |
| 53 | UDP/TCP | DNS |
| 80 | TCP | HTTP |
| 443 | TCP | HTTPS |
| 3306 | TCP | MySQL |
| 5432 | TCP | PostgreSQL |
| 6379 | TCP | Redis |
| 27017 | TCP | MongoDB |
| 8080 | TCP | Dev/proxy HTTP (unofficial) |

Port numbers 0–1023 are "well-known" — only root/admin can bind to them.  
Ports 1024–49151 are "registered" — common for applications.  
Ports 49152–65535 are "ephemeral" — OS assigns these for outgoing connections.

---

## TCP connection states

```
LISTEN        → waiting for incoming connections
SYN_SENT      → your machine initiated a connection
SYN_RECEIVED  → received SYN, sent SYN-ACK
ESTABLISHED   → connection active, data flowing
FIN_WAIT_1    → your machine initiated close
TIME_WAIT     → waiting to ensure remote received close (lasts ~60s)
CLOSE_WAIT    → remote closed, your app hasn't closed yet
CLOSED        → connection fully terminated
```

---

## The test server exercise

```bash
# Terminal 1 — start server
python3 -m http.server 8080

# Terminal 2 — verify it appears
netstat -an | grep 8080
# should show: tcp4  0  0  0.0.0.0.8080  0.0.0.0.*  LISTEN

# Terminal 2 — make a connection to it
curl http://localhost:8080

# Terminal 2 — now check for ESTABLISHED connection while curl runs
netstat -an | grep 8080
# You may catch: tcp4  0  0  127.0.0.1.8080  127.0.0.1.xxxxx  ESTABLISHED
```

---

## Your answers

```
Ports your machine is currently LISTEN on:
  1. _______  service: _______________________
  2. _______  service: _______________________
  3. _______  service: _______________________

Is port 5432 (PostgreSQL) open on your machine? (yes/no): _______
Is port 22 (SSH) open? (yes/no):                          _______
Is port 8080 open after starting python server? (yes/no): _______

0.0.0.0 vs 127.0.0.1 — what is the difference?
_____________________________________________________________

After stopping the python server, does port 8080 disappear from netstat?
_____________________________________________________________
```

---

## Screenshot

> Add output showing:
> 1. Your listening ports
> 2. The python server appearing in netstat
>
> ```
> ![netstat output](../screenshots/4-ports.png)
> ```

---

## Reflection questions

1. If a service listens on `0.0.0.0:8080`, can someone on the internet connect to it? What else would need to be true?
2. What is the risk of running a database (like PostgreSQL) with listen address `0.0.0.0` instead of `127.0.0.1`?
3. Why do closed TCP connections linger in `TIME_WAIT` state for ~60 seconds before disappearing?
4. You have an application that can't connect to a service. What `netstat` / `ss` commands would you run to diagnose it?

> Write your answers here.

---

*Previous: [Exercise 3 — DNS](./3-dns.md) | Next: [Exercise 5 — curl](./5-curl.md)*
