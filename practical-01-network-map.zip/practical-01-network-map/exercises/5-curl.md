# Exercise 5 — Capture and inspect a real HTTP/S request

**Concept:** HTTP protocol, TLS handshake, headers, OSI Layers 6 & 7

---

## Commands to run

```bash
# Full verbose HTTPS request — see every step
curl -v https://httpbin.org/get

# Headers only (no body)
curl -I https://github.com

# With timestamps — see where time is spent
curl -v --trace-time https://httpbin.org/get

# Timing breakdown — DNS, TCP connect, TLS, total
curl -o /dev/null -s -w \
  "DNS lookup:    %{time_namelookup}s\nTCP connect:   %{time_connect}s\nTLS handshake: %{time_appconnect}s\nFirst byte:    %{time_starttransfer}s\nTotal:         %{time_total}s\n" \
  https://github.com

# Compare HTTP (no TLS) vs HTTPS
curl -o /dev/null -s -w "Total: %{time_total}s\n" http://httpbin.org/get
curl -o /dev/null -s -w "Total: %{time_total}s\n" https://httpbin.org/get

# Follow redirects and show the chain
curl -vL http://github.com       # note: HTTP redirects to HTTPS
```

---

## Reading curl -v output section by section

```
* Trying 54.208.105.16:443...          ← DNS resolved, TCP connecting
* Connected to httpbin.org port 443    ← TCP connection established (Layer 4)

* TLSv1.3 (OUT), TLS handshake, Client hello  ← TLS begins (Layer 6)
* TLSv1.3 (IN),  TLS handshake, Server hello
* TLSv1.3 (IN),  TLS handshake, Certificate
* TLSv1.3 (IN),  TLS handshake, CERT verify
* TLSv1.3 (IN),  TLS handshake, Finished
* TLSv1.3 (OUT), TLS handshake, Finished
* SSL connection using TLSv1.3 / TLS_AES_256_GCM_SHA384  ← cipher suite agreed

> GET /get HTTP/2                       ← HTTP request sent (Layer 7)
> Host: httpbin.org
> User-Agent: curl/8.1.2
> Accept: */*

< HTTP/2 200                            ← HTTP response
< content-type: application/json
< date: Mon, 01 Jan 2024 00:00:00 GMT
< content-length: 312
< server: gunicorn/19.9.0
```

---

## The TLS handshake explained

```
Client                              Server
  |                                   |
  |──── Client Hello ────────────────>|  "I support TLS 1.3, here are cipher suites"
  |<─── Server Hello ─────────────────|  "Let's use TLS_AES_256_GCM_SHA384"
  |<─── Certificate ──────────────────|  "Here's my cert proving I'm really github.com"
  |<─── Server Finished ──────────────|
  |──── Client Finished ─────────────>|
  |                                   |
  |═══════ Encrypted data ════════════|  All HTTP traffic from here is encrypted
```

The certificate is signed by a trusted Certificate Authority (CA). Your OS/browser has a built-in list of trusted CAs — if the cert chains to one of them, you trust it.

---

## Common HTTP response codes

| Code | Meaning | When you see it |
|------|---------|----------------|
| 200 | OK | Successful request |
| 201 | Created | POST created a resource |
| 301 | Moved Permanently | Redirect (cached by browser) |
| 302 | Found | Temporary redirect |
| 400 | Bad Request | Malformed request |
| 401 | Unauthorized | Authentication required |
| 403 | Forbidden | Authenticated but not permitted |
| 404 | Not Found | Resource doesn't exist |
| 429 | Too Many Requests | Rate limited |
| 500 | Internal Server Error | Server-side bug |
| 502 | Bad Gateway | Proxy/load balancer upstream error |

---

## Useful HTTP response headers

| Header | Purpose | Example |
|--------|---------|---------|
| `Content-Type` | Format of the response body | `application/json` |
| `Cache-Control` | How long browser can cache this | `max-age=3600` |
| `Strict-Transport-Security` | Force HTTPS on future visits (HSTS) | `max-age=31536000` |
| `X-Frame-Options` | Block iframe embedding (clickjacking protection) | `DENY` |
| `Content-Security-Policy` | Which origins can load scripts/media | `default-src 'self'` |
| `Location` | Redirect destination | `https://github.com/` |
| `Set-Cookie` | Set a browser cookie | `session=abc123; Secure; HttpOnly` |

---

## Timing breakdown explained

```
DNS lookup:    0.012s   ← time to resolve the hostname to IP
TCP connect:   0.089s   ← time for TCP 3-way handshake (DNS + TCP)
TLS handshake: 0.213s   ← time to complete TLS (DNS + TCP + TLS)
First byte:    0.341s   ← time to receive first response byte
Total:         0.412s   ← full download complete
```

TLS overhead = `time_appconnect - time_connect` (in this example: 0.213 - 0.089 = **124ms**)

---

## Your answers

```bash
# After running: curl -v https://httpbin.org/get

TLS version negotiated:           _______________________
Cipher suite:                     _______________________
HTTP status code:                 _______________________
Content-Type header:              _______________________
Server header:                    _______________________

# After running the timing command on https://github.com

DNS lookup time:                  _______s
TCP connect time:                 _______s
TLS handshake overhead:           _______s  (appconnect - connect)
Total request time:               _______s

# After running: curl -vL http://github.com

Does HTTP redirect to HTTPS?      (yes/no): _______
What status code is the redirect? _______
What header contains the redirect URL? _______________________
```

---

## Screenshot

> Add your annotated `curl -v` output here, highlighting:
> 1. The TLS handshake lines
> 2. The HTTP request headers
> 3. The HTTP response headers
>
> ```
> ![curl output](../screenshots/5-curl.png)
> ```

---

## Reflection questions

1. HTTP sends all data in plaintext. Demonstrate this by running `curl -v http://httpbin.org/get` — what's the difference in the output vs HTTPS?
2. What is the purpose of `Strict-Transport-Security`? What attack does it prevent?
3. The TLS certificate proves the server is who it claims to be. Who issues these certificates, and why do browsers trust them?
4. Look at the `Set-Cookie` header on a response. What do the `Secure` and `HttpOnly` flags do?

> Write your answers here.

---

## Bonus: inspect without TLS verification (for learning only — never in production)

```bash
# Skip cert verification to see the request go through even with invalid cert
curl -k https://self-signed.badssl.com/
# This is what happens when you accept an invalid certificate — dangerous!
```

---

*Previous: [Exercise 4 — Ports](./4-ports.md) | Back to [README](../README.md)*
