# Exercise 2 — Trace a packet's route to google.com

**Concept:** IP routing, TTL (Time to Live), network hops, OSI Layer 3

---

## Commands to run

```bash
# macOS / Linux
traceroute google.com
traceroute -n google.com          # IPs only, no reverse DNS lookup (faster)
traceroute -m 30 google.com       # max 30 hops

# Windows
tracert google.com
tracert -d google.com             # no DNS resolution

# Alternative (uses TCP instead of ICMP — works through more firewalls)
traceroute -T -p 443 google.com
```

---

## How traceroute works

Traceroute exploits the **TTL (Time to Live)** field in IP packets.

```
Your machine sends packet with TTL=1
  → Router 1 decrements TTL to 0, drops packet, sends ICMP "Time Exceeded" back
    → You record Router 1's IP and RTT

Your machine sends packet with TTL=2
  → Router 1 decrements to 1, forwards it
  → Router 2 decrements to 0, sends ICMP "Time Exceeded"
    → You record Router 2's IP and RTT

... and so on until the packet reaches the destination
```

Each line in the output = one router = one **hop**.

---

## Reading the output

```
traceroute to google.com (142.250.80.46), 30 hops max
 1  192.168.1.1      2.3 ms   1.9 ms   2.1 ms   ← your home router
 2  10.10.0.1       12.4 ms  11.8 ms  12.0 ms   ← ISP gateway
 3  196.x.x.x       15.2 ms  14.9 ms  15.1 ms   ← ISP backbone
 4  * * *                                         ← router not responding to ICMP
 5  72.14.x.x       18.3 ms  17.9 ms  18.1 ms   ← Google's network edge
 6  142.250.80.46   19.1 ms  18.8 ms  18.9 ms   ← destination
```

| Column | Meaning |
|--------|---------|
| Number | Hop count from your machine |
| IP address | The router at that hop |
| 3× RTT values | Three probes sent — shows consistency or packet loss |
| `* * *` | Router dropped the probe (ICMP filtered by firewall) — normal |

### RTT pattern to expect
- Hop 1 (your router): 1–5 ms
- Hop 2–3 (ISP): 5–20 ms
- Hops crossing continents: 100–300 ms
- Sudden jump = long-haul fibre link (e.g. undersea cable)

---

## Annotating your hops

Use this table structure in your write-up:

| Hop | IP | RTT | What it likely is |
|-----|-----|-----|-------------------|
| 1 | 192.168.1.1 | ~2ms | Your home router |
| 2 | 10.x.x.x | ~12ms | ISP's first router (CGNAT) |
| 3–5 | 196.x.x.x | ~15ms | ISP backbone |
| 6+ | 72.14.x.x | ~18ms | Google's AS15169 network |
| Last | 142.250.x.x | ~19ms | Google destination server |

**Tip:** Look up IPs at [ipinfo.io](https://ipinfo.io) to find the organisation (ASN) that owns each hop.

---

## Your answers

```
Total hops to google.com:            _______
RTT at hop 1 (your router):          _______
RTT at final hop:                    _______
First hop outside your ISP:          hop ___  IP: _______________
Any * * * hops? (yes/no):            _______
If yes, at which hop(s)?             _______
Destination IP:                      _______
```

---

## Screenshot

> Add your full traceroute output here.
>
> ```
> ![traceroute output](../screenshots/2-traceroute.png)
> ```

---

## Reflection questions

1. Why do three RTT values appear per hop instead of just one?
2. What does it mean when a hop shows `* * *`? Does it mean the connection is broken?
3. Why does RTT generally increase with each hop?
4. If a hop has *higher* RTT than the hop after it, what could explain that?

> Write your answers here.

---

*Previous: [Exercise 1 — ifconfig](./1-ifconfig.md) | Next: [Exercise 3 — DNS](./3-dns.md)*
