# Exercise 3 — Resolve DNS manually

**Concept:** DNS record types, recursive resolution, TTL, OSI Layer 7 over UDP

---

## Commands to run

```bash
# Basic lookups
nslookup google.com
nslookup -type=A google.com         # IPv4 address record
nslookup -type=AAAA google.com      # IPv6 address record
nslookup -type=MX gmail.com         # mail exchanger records
nslookup -type=CNAME www.github.com # canonical name (alias)
nslookup -type=TXT github.com       # text records (SPF, DKIM, etc.)

# dig — more detailed output
dig google.com
dig google.com A
dig gmail.com MX
dig github.com TXT
dig @8.8.8.8 google.com             # query Google DNS directly (bypass your ISP)
dig @1.1.1.1 google.com             # query Cloudflare DNS directly
dig +trace google.com               # show full recursive resolution chain
```

---

## DNS record types explained

| Record | Purpose | Example |
|--------|---------|---------|
| `A` | Maps hostname → IPv4 address | `google.com → 142.250.80.46` |
| `AAAA` | Maps hostname → IPv6 address | `google.com → 2607:f8b0::...` |
| `CNAME` | Alias — points one name to another | `www.github.com → github.com` |
| `MX` | Mail server for a domain | `gmail.com → alt1.gmail-smtp-in.l.google.com` |
| `TXT` | Arbitrary text — used for SPF, DKIM, verification | `"v=spf1 include:_spf.google.com ~all"` |
| `NS` | Nameserver for a domain | `google.com → ns1.google.com` |
| `PTR` | Reverse DNS — IP → hostname | `142.250.80.46 → lga34s32-in-f14.1e100.net` |

---

## Reading dig output

```bash
$ dig google.com

; <<>> DiG 9.18 <<>> google.com
;; QUESTION SECTION:
;google.com.                IN      A        ← we asked for A record

;; ANSWER SECTION:
google.com.         300     IN      A       142.250.80.46
                    ↑TTL             ↑type   ↑answer

;; Query time: 12 msec
;; SERVER: 192.168.1.1#53             ← which DNS server answered
;; WHEN: ...
;; MSG SIZE  rcvd: 55
```

Key fields:
- **TTL (300)** — seconds this answer can be cached before re-querying
- **SERVER** — which DNS resolver actually answered
- **Query time** — how fast the DNS lookup was

---

## How recursive resolution works (dig +trace)

```bash
dig +trace google.com
```

This shows the full chain:

```
.                  → Root nameservers (13 globally)
com.               → .com TLD nameservers (run by Verisign)
google.com.        → Google's own authoritative nameservers
                   → Returns the A record
```

Your DNS resolver (usually your router or ISP) walks this chain on your behalf and caches the result.

---

## Your answers

```bash
# Run each command and fill in the results

dig google.com A
  → IP address returned:          _______________________
  → TTL:                          _______________________
  → Which DNS server answered:    _______________________

dig gmail.com MX
  → Mail server hostname:         _______________________
  → Priority number:              ________ (lower = preferred)

dig github.com TXT
  → What does the SPF record say? _______________________

dig @8.8.8.8 google.com vs dig @1.1.1.1 google.com
  → Same IP? (yes/no):            _______
  → Different query times?        _______ ms vs _______ ms
```

---

## Screenshot

> Add your `dig +trace google.com` output here — this shows the full recursive chain.
>
> ```
> ![dig trace output](../screenshots/3-dns-trace.png)
> ```

---

## Reflection questions

1. What is the purpose of TTL in a DNS record? What happens when it expires?
2. Why would a company use a low TTL (e.g. 60 seconds) vs a high one (e.g. 86400)?
3. What is the difference between querying `@8.8.8.8` directly vs your default resolver?
4. You have `nslookup -type=MX gmail.com`. Why does email routing need its own record type instead of just using the A record?

> Write your answers here.

---

*Previous: [Exercise 2 — Traceroute](./2-traceroute.md) | Next: [Exercise 4 — Ports](./4-ports.md)*
